package fi.haagahelia.backend.divelog.domain;

import org.springframework.data.repository.CrudRepository;

public interface AdminUserRepository extends CrudRepository<AdminUser, Long>{
	
}
