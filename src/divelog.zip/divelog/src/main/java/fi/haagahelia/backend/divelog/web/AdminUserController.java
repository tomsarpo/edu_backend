package fi.haagahelia.backend.divelog.web;

public class AdminUserController {

}
