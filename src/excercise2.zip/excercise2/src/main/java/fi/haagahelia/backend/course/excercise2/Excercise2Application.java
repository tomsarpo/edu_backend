package fi.haagahelia.backend.course.excercise2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Excercise2Application {

	public static void main(String[] args) {
		SpringApplication.run(Excercise2Application.class, args);
	}

}

