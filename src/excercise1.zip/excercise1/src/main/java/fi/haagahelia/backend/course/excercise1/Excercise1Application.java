package fi.haagahelia.backend.course.excercise1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Excercise1Application {

	public static void main(String[] args) {
		SpringApplication.run(Excercise1Application.class, args);
	}

}

